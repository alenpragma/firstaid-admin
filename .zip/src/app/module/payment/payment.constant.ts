export const ordersFilterableFields = ['searchTerm', 'trxId', 'phone'];

export const ordersSearchableFields = ['trxId', 'phone', 'trxId'];
