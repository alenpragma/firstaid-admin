export const ordersFilterableFields = [
  'searchTerm',
  'lastName',
  'phone',
  'price',
  'email',
];

export const ordersSearchableFields = ['Category', 'Brand', 'Price'];
