export const EVENT_STUDENT_CREATED = 'student.created';
export const EVENT_FACULTY_CREATED = 'faculty.created';
